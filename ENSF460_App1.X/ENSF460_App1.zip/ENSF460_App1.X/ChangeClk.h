/* 
 * File:   ChangeClk.h
 * Author: rvyas
 *
 * Created on November 19, 2016, 8:05 PM
 */

#ifndef CHANGECLK_H
#define	CHANGECLK_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif


void NewClk(unsigned int);

#endif	/* CHANGECLK_H */

